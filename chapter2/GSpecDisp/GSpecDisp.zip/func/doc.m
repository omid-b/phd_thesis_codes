function doc(~,~)

    open('GSpecDisp_tutorial.pdf')

end