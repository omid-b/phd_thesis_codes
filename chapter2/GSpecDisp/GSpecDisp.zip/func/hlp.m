function hlp(~,~)

    open('GSpecDisp_manual.pdf')

end