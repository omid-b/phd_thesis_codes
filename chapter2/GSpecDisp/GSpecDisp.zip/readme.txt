Copyright (c) 2016, Hamzeh Sadeghisorkhani
All rights reserved.

A Matlab GUI package for phase velocity measurments from ambient noise correlations

To start: run the GSpecDisp.m file
Manual and tutorial are in the Doc folder


TERMS OF USE
   If you use GSpecDisp or any function(s) of it, you need to acknowledge 
   GSpecDisp by citing the following article:

   Sadeghisorkhani, H., Gudmundsson, O., Tryggvason, A., 2017. GSpecDisp: a 
   Matlab GUI package for phase-velocity dispersion measurements from 
   ambient-noise correlations, Computers and Geosciences, under review.   
   
 
LICENSE:
   This program is part of GSpecDisp
   GSpecDisp is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.
      GSpecDisp is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
       You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.
